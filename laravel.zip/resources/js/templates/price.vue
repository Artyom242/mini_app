<template>
    <div class="section_start_title">
        <div class="container_rel" style="z-index: 11">
            <h2 class="title_big margin_title ml_5">Прайс-лист</h2>
            <div class="flex row gap_10">
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Консультация врача</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20">
                        <p class="little_text">Рекомендуется каждые пол года проходить осмотр</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">300</p>
                        </div>
                    </div>
                </div>
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Анестезия</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20 flex_full_height">
                        <p class="little_text">Обеспечивает комфорт и отсутствие боли при процедурах</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">500</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Терапия-->
        <div class="section_mt container_rel">
            <img class="img_fon img_list" :src="`/images/price-list.webp`">

            <h2 class="title_big margin_title ml_5">Терапия</h2>
            <div class="block_card flex container_rel mb_10">
                <div class="mb_10">
                    <h4 class="block_card_price--title title">Лечение кариеса</h4>
                    <div class="blue_line"></div>
                </div>
                <div class="mb_20">
                    <p class="little_text">Начальная стадия кариеса может быть вылечена без сверления</p>
                </div>
                <div class="flex gap_10">
                    <div class="block_card flex gap_30 row flex-center-text border_blue">
                        <div>
                            <h4 class="title">Пломба химического отверждения</h4>
                        </div>
                        <div class="block_price">
                            <div class="flex column" style="text-align: end">
                                <p class="title_big">2000</p>
                                <p class="text-white">до 2500</p>
                            </div>
                        </div>
                    </div>
                    <div class="block_card flex row gap_30 flex-center-text block_card-blue">
                        <div>
                            <h4 class=" title">Пломба светового отверждения</h4>
                        </div>
                        <div class="block_price">
                            <div class="flex column" style="text-align: end">
                                <p class="title_big">3000</p>
                                <p class="text-white">до 4000</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex row gap_10 mb_10">
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Лечение периодонтита</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20">
                        <p class="little_text">Здоровые десны — залог крепких зубов</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">7500</p>
                        </div>
                    </div>
                </div>
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Реставрация зуба</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20 flex_full_height">
                        <p class="little_text">Современные материалы делают реставрацию почти незаметной</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">5000</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="block_card flex">
                <div class="mb_10">
                    <h4 class="block_card_price--title title">Лечение пульпита</h4>
                    <div class="blue_line"></div>
                </div>
                <div class="mb_20">
                    <p class="little_text">Основная причина пульпита — осложненный кариес</p>
                </div>
                <div class="flex gap_10">
                    <div class="block_card flex gap_30 row flex-center-text border_blue">
                        <div>
                            <h4 class="title">Однокорневого зуба</h4>
                        </div>
                        <div class="block_price">
                            <div class="flex column" style="text-align: end">
                                <p class="title_big">5800</p>
                            </div>
                        </div>
                    </div>
                    <div class="block_card flex row gap_30 flex-center-text block_card-blue">
                        <div>
                            <h4 class="title">Трехкорневого зуба </h4>
                        </div>
                        <div class="block_price">
                            <div class="flex column" style="text-align: end">
                                <p class="title_big">6800</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Ортопедия-->
        <div class="section_mt container_rel">
            <img class="img_fon img_tooth" :src="`/images/price-tooth.webp`">
            <h2 class="title_big margin_title ml_5">Ортопедия</h2>
            <div class="flex row gap_10 mb_10">
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Фиксация коронки</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20">
                        <p class="little_text">Коронки из циркония могут служить до 20 лет</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">500</p>
                        </div>
                    </div>
                </div>
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Вкладка ортопедическая</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20 flex_full_height">
                        <p class="little_text">Вкладка восстанавливает форму и функцию зуба, избегая коронки</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">5000</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="block_card flex mb_10">
                <div class="mb_10">
                    <h4 class="block_card_price--title title">Коронка</h4>
                    <div class="blue_line"></div>
                </div>
                <div class="mb_20">
                    <p class="little_text">Процесс установки коронки занимает два визита к стоматологу</p>
                </div>
                <div class="flex gap_10">
                    <div class="block_card flex gap_30 row flex-center-text border_blue">
                        <div>
                            <h4 class="title">Металлическая</h4>
                        </div>
                        <div class="block_price">
                            <div class="flex column" style="text-align: end">
                                <p class="title_big">5500</p>
                            </div>
                        </div>
                    </div>
                    <div class="block_card flex row gap_30 flex-center-text block_card-blue">
                        <div>
                            <h4 class=" title">Металлокерамическая</h4>
                        </div>
                        <div class="block_price">
                            <div class="flex column" style="text-align: end">
                                <p class="title_big">9500</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Чистка зубов-->
        <div class="section_mt container_rel">
            <img class="img_fon img_brash" :src="`/images/price-brash.webp`">
            <h2 class="title_big margin_title ml_5">Чистка зубов</h2>
            <div class="flex row gap_10">
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Чистка ультразвуковая</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20">
                        <p class="little_text">Ультразвуковые волны расщепляют даже самые стойкие загрязнения</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">2500</p>
                        </div>
                    </div>
                </div>
                <div class="block_card flex">
                    <div class="mb_10">
                        <h4 class="block_card_price--title title">Чистка пескоструйная</h4>
                        <div class="blue_line"></div>
                    </div>
                    <div class="mb_20 flex_full_height">
                        <p class="little_text">Удаляет мягкий налет и пигментацию с поверхности зубов</p>
                    </div>
                    <div class="block_price">
                        <div class="flex column" style="text-align: end">
                            <p class="title_big">2500</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "PricesPage",

    mounted() {
        let tg = window.Telegram.WebApp;
        let btn = Telegram.WebApp.BackButton;
        btn.show();
        btn.onClick(this.pageBack);
        tg.MainButton.hide();
    },
    methods: {
        pageBack() {
            window.history.back();
            Telegram.WebApp.BackButton.hide();
        }
    }
}
</script>

<style>
.block_card_price--title {
    margin-bottom: 10px;
    color: white;
}

.text-white {
    color: white;
}

.gap_30 {
    gap: 30px;
}

.flex-center-text {
    align-items: center;
}

.container_rel {
    z-index: 10;
    position: relative;
}

.img_fon {
    position: absolute;
    z-index: 0;
    filter: brightness(70%);
}

.img_list {
    top: -80px;
    right: -10px;
    width: 200px;
    transform: rotate(10deg);
}

.img_tooth {
    top: -50px;
    right: -20px;
    width: 190px;
    transform: rotate(-10deg);
}
.img_brash{
    top: -83px;
    right: -40px;
    width: 230px;
    transform: rotate(-30deg);
}

.blue_line {
    width: 55px;
    border-radius: 10px;
    background: #1d7bf6;
    height: 3px;
}

.border_blue {
    border: 2px solid #224c85;
}

.mb_10 {
    margin-bottom: 10px;
}
.mb_5{
    margin-bottom: 5px;
}

.mb_20 {
    margin-bottom: 20px;
}

.block_price {
    text-align: end;
}

</style>


