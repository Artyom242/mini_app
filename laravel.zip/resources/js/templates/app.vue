<template>
    <section class="section_white">
        <div class="__container wrapper flex gap_15">
            <router-view/>
        </div>
    </section>
</template>

<script>
export default {
    name: "App"
};
</script>
